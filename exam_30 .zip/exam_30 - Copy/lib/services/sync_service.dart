import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/loyalty_card.dart';
import 'database_service.dart';

class SyncService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseService _dbService = DatabaseService();

  Future<void> syncCards() async {
    if (_auth.currentUser == null) return;

    // Get unsynced local cards
    final unsyncedCards = await _dbService.getUnsyncedCards();

    // Upload unsynced cards to Firestore
    for (var card in unsyncedCards) {
      await _firestore
          .collection('users')
          .doc(_auth.currentUser!.uid)
          .collection('cards')
          .doc(card.id.toString())
          .set(card.toMap());

      // Mark card as synced
      await _dbService.updateCard(card.copyWith(isSynced: true));
    }

    // Get remote cards
    final remoteSnapshot =
        await _firestore
            .collection('users')
            .doc(_auth.currentUser!.uid)
            .collection('cards')
            .get();

    // Update local database with remote changes
    for (var doc in remoteSnapshot.docs) {
      final remoteCard = LoyaltyCard.fromMap(doc.data());
      final localCard = await _dbService.getCard(remoteCard.id!);

      if (localCard == null) {
        // New card from remote
        await _dbService.insertCard(remoteCard);
      } else if (localCard.lastUsed.isBefore(remoteCard.lastUsed)) {
        // Remote card is newer
        await _dbService.updateCard(remoteCard);
      }
    }
  }

  Future<void> syncCard(LoyaltyCard card) async {
    if (_auth.currentUser == null) return;

    await _firestore
        .collection('users')
        .doc(_auth.currentUser!.uid)
        .collection('cards')
        .doc(card.id.toString())
        .set(card.toMap());

    await _dbService.updateCard(card.copyWith(isSynced: true));
  }

  Future<void> deleteCard(int cardId) async {
    if (_auth.currentUser == null) return;

    await _firestore
        .collection('users')
        .doc(_auth.currentUser!.uid)
        .collection('cards')
        .doc(cardId.toString())
        .delete();

    await _dbService.deleteCard(cardId);
  }
}
