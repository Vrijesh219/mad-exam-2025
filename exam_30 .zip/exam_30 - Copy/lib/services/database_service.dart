import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/loyalty_card.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  static Database? _database;

  factory DatabaseService() => _instance;

  DatabaseService._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'loyalty_cards.db');
    return await openDatabase(path, version: 1, onCreate: _createDb);
  }

  Future<void> _createDb(Database db, int version) async {
    await db.execute('''
      CREATE TABLE loyalty_cards(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        cardNumber TEXT NOT NULL,
        barcode TEXT NOT NULL,
        barcodeType TEXT,
        expiryDate TEXT NOT NULL,
        notes TEXT,
        imagePath TEXT,
        lastUsed TEXT NOT NULL,
        isSynced INTEGER NOT NULL,
        points INTEGER NOT NULL
      )
    ''');
  }

  Future<int> insertCard(LoyaltyCard card) async {
    final db = await database;
    return await db.insert('loyalty_cards', card.toMap());
  }

  Future<List<LoyaltyCard>> getAllCards() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('loyalty_cards');
    return List.generate(maps.length, (i) => LoyaltyCard.fromMap(maps[i]));
  }

  Future<LoyaltyCard?> getCard(int id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'loyalty_cards',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isEmpty) return null;
    return LoyaltyCard.fromMap(maps.first);
  }

  Future<int> updateCard(LoyaltyCard card) async {
    final db = await database;
    return await db.update(
      'loyalty_cards',
      card.toMap(),
      where: 'id = ?',
      whereArgs: [card.id],
    );
  }

  Future<int> deleteCard(int id) async {
    final db = await database;
    return await db.delete('loyalty_cards', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<LoyaltyCard>> getUnsyncedCards() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'loyalty_cards',
      where: 'isSynced = ?',
      whereArgs: [0],
    );
    return List.generate(maps.length, (i) => LoyaltyCard.fromMap(maps[i]));
  }

  Future<List<LoyaltyCard>> getExpiringCards(DateTime date) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'loyalty_cards',
      where: 'expiryDate <= ?',
      whereArgs: [date.toIso8601String()],
    );
    return List.generate(maps.length, (i) => LoyaltyCard.fromMap(maps[i]));
  }
}
