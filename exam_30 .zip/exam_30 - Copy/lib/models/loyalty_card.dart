import 'dart:convert';
import 'package:encrypt/encrypt.dart' as encrypt;

class LoyaltyCard {
  final int? id;
  final String name;
  final String cardNumber;
  final String barcode;
  final String? barcodeType;
  final DateTime expiryDate;
  final String? notes;
  final String? imagePath;
  final DateTime lastUsed;
  final bool isSynced;
  final int points;

  LoyaltyCard({
    this.id,
    required this.name,
    required this.cardNumber,
    required this.barcode,
    this.barcodeType,
    required this.expiryDate,
    this.notes,
    this.imagePath,
    required this.lastUsed,
    this.isSynced = false,
    this.points = 0,
  });

  // Encrypt sensitive data
  String get encryptedCardNumber {
    final key = encrypt.Key.fromLength(32);
    final iv = encrypt.IV.fromLength(16);
    final encrypter = encrypt.Encrypter(encrypt.AES(key));
    return encrypter.encrypt(cardNumber, iv: iv).base64;
  }

  // Convert to Map for database operations
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'cardNumber': encryptedCardNumber,
      'barcode': barcode,
      'barcodeType': barcodeType,
      'expiryDate': expiryDate.toIso8601String(),
      'notes': notes,
      'imagePath': imagePath,
      'lastUsed': lastUsed.toIso8601String(),
      'isSynced': isSynced ? 1 : 0,
      'points': points,
    };
  }

  // Create from Map for database operations
  factory LoyaltyCard.fromMap(Map<String, dynamic> map) {
    return LoyaltyCard(
      id: map['id'],
      name: map['name'],
      cardNumber: map['cardNumber'], // Note: This will be encrypted
      barcode: map['barcode'],
      barcodeType: map['barcodeType'],
      expiryDate: DateTime.parse(map['expiryDate']),
      notes: map['notes'],
      imagePath: map['imagePath'],
      lastUsed: DateTime.parse(map['lastUsed']),
      isSynced: map['isSynced'] == 1,
      points: map['points'],
    );
  }

  // Create a copy with updated fields
  LoyaltyCard copyWith({
    int? id,
    String? name,
    String? cardNumber,
    String? barcode,
    String? barcodeType,
    DateTime? expiryDate,
    String? notes,
    String? imagePath,
    DateTime? lastUsed,
    bool? isSynced,
    int? points,
  }) {
    return LoyaltyCard(
      id: id ?? this.id,
      name: name ?? this.name,
      cardNumber: cardNumber ?? this.cardNumber,
      barcode: barcode ?? this.barcode,
      barcodeType: barcodeType ?? this.barcodeType,
      expiryDate: expiryDate ?? this.expiryDate,
      notes: notes ?? this.notes,
      imagePath: imagePath ?? this.imagePath,
      lastUsed: lastUsed ?? this.lastUsed,
      isSynced: isSynced ?? this.isSynced,
      points: points ?? this.points,
    );
  }
}
